clc;clear;clf;

k = 8.617e-5
T=5000;
Ef=0;
d=k*T;

E1=linspace(-3,3,1000);
E2=linspace(0,3,1000);

for i=1:1000 
  f2(i) = 1/(exp((E2(i)-Ef)/d)); 
  f1(i) = 1/(1+exp(E1(i)/d)); 
end

plot(E1,f1,'r','linewidth',1);
hold on;
plot(E2,f2,'b','linewidth',1);
grid on;

h = legend(['Fermi-Dirac';'Maxwell-Boltzmann']);
xlabel("Energy(in eV)",'fontsize',20);
ylabel("Occupation Probability f(E)",'fontsize',20);
set(gca, "fontsize", 20)
title('F-D and M-B Statistics at 5000K','fontsize',20);
set (h, "fontsize", 18);
hold off;