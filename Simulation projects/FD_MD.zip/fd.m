clc;clear;clf;

k = 8.617e-5;
T1=0;
T2=235;
T3=2500;
T4=5000;
Ef=0;

d1=k*T1;
d2=k*T2;
d3=k*T3;
d4=k*T4;

E=linspace(-1,1,1000);

for i=1:1000 
  w1(i)=1/(1+exp((E(i)-Ef)/d1)); 
  w2(i)=1/(1+exp((E(i)-Ef)/d2)); 
  w3(i)=1/(1+exp((E(i)-Ef)/d3)); 
  w4(i)=1/(1+exp((E(i)-Ef)/d4)); 
end

plot(E,w1,'r','linewidth',1);
hold on;
plot(E,w2,'b','linewidth',1);
hold on;
plot(E,w3,'k','linewidth',1);
hold on;
plot(E,w4,'g','linewidth',1);
grid on;

h = legend(['T1 = 0K';'T2 = 235K';'T3 = 2500K';'T4 = 5000K']);
xlabel("Energy(in eV)",'fontsize',20);
ylabel("Occupation Probability f(E)",'fontsize',20);
set(gca, "fontsize", 20)
title('Fermi-Dirac Statistics','fontsize',20);
set (h, "fontsize", 18);
hold off;