% How the carrier density varies with respect to the energy ?
% carrier(hole) density for p-type semiconductor = p = n(E)=int(D(E)f(E)dE)
% p = Nv*exp(-(Ef-Ev)/kT) where Nv=2((2*pi*mp*k*T)/(h^2))^(3/2)

clc;clear;clf;

k1 = 8.617e-5; %eV per kelvin
k2 = 1.38e-23; %joule per kelvin
T = 300; %kelvin
Ef = 0; %eV
mp=9.1e-31;
h = 6.626e-34; %

d1 = h*h;
d2 = k1*T;

Ev = linspace(-0.5,0,1000);

N = 2*(((2*pi*mp*k2*T)/(d1))^(1.5));

for i = 1:1000
  p(i) = (N)*(exp(-(Ef-Ev(i))/(d2))); 
end

plot(Ev,p,'r','linewidth',1);
grid on;

xlabel("Energy(in eV)",'fontsize',20);
ylabel("Carrier density (per cubic meter)",'fontsize',20);
set(gca, "fontsize", 20)
title('Carrier density in p-type semiconductor','fontsize',20);
