clc;clear;clf;

k = 8.617e-5;

T1=0.0000001;
T2=235;
T3=2500;
T4=5000;

Ef=0;

d1=k*T1;
d2=k*T2;
d3=k*T3;
d4=k*T4;

E=linspace(0,3,1000);

for i=1:1000 
  f1(i)=1/(exp((E(i)-Ef)/d1)); 
  f2(i)=1/(exp((E(i)-Ef)/d2)); 
  f3(i)=1/(exp((E(i)-Ef)/d3)); 
  f4(i)=1/(exp((E(i)-Ef)/d4)); 
end

plot(E,f1,'r','linewidth',1);
hold on;
plot(E,f2,'b','linewidth',1);
hold on;
plot(E,f3,'g','linewidth',1);
hold on;
plot(E,f4,'k','linewidth',1);
grid on;

h = legend(['T1 = 0K';'T2 = 235K';'T3 = 2500K';'T4 = 5000K']);
xlabel("Energy(in eV)",'fontsize',20);
ylabel("Occupation Probability f(E)",'fontsize',20);
set(gca, "fontsize", 20)
title('Maxwell-Boltzmann Statistics','fontsize',20);
set (h, "fontsize", 18);
hold off;