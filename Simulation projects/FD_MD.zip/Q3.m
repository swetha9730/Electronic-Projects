% How does the intrinsic carrier concentration changes with respect to
% the temperature ? Assume effective density of states for conduction
% and valence band to be 2.8E19 cm3 and 1.8E19cm3. Assume doping
% to be 1E17 cm3 and comment on the nature of semiconductor. Plot
% ni on a semilog scale versus (1000/T)

clc;clear;close;

Nc = 2.8e19;  %cm3
Nv = 1.8e19;  %cm3
Nd = 1e17; %cm3 
k = 8.617e-5; %eV per kelvin
Eg = 1.12; %eV
%semiconductor assumed to be Silicon
NcNv = Nc*Nv;

T = linspace(100,100000,1000); 
x = 1000./T;

ni = exp(0.5*log(NcNv)-Eg/(2000*k)*x);

semilogy(x,ni,linewidth=1);
grid on;
set(gca, "fontsize", 20);
xlabel("1000/T",'fontsize',25);
ylabel("Intrinsic carrier concentration(logarithmic scale)",'fontsize',25);

title('Intrinsic carrier concentration with respect to temperature','fontsize',30);
hold off;